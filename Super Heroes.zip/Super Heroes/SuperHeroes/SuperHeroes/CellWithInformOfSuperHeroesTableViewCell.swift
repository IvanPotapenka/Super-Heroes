//
//  CellWithInformOfSuperHeroesTableViewCell.swift
//  SuperHeroes
//
//  Created by asus on 3/23/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import UIKit

class CellWithInformOfSuperHeroesTableViewCell: UITableViewCell {

    @IBOutlet var imageSuperHero: UIImageView!
    @IBOutlet var nameSuperHero: UILabel!
    @IBOutlet var powerstatsSuperHero: UILabel!
    @IBOutlet var intelligenceSuperHero: UILabel!
    @IBOutlet var strengthSuperHero: UILabel!
    @IBOutlet var powerSuperHero: UILabel!
   
    func configureOfCell(with param: SuperHeroInformation) {
        nameSuperHero.text  = param.name
        powerstatsSuperHero.text = "Powerstats"
        intelligenceSuperHero.text = "Intelligence: \(param.powerstats?.intelligence ?? 0)"
        strengthSuperHero.text = "Strenght: \(param.powerstats?.strength ?? 0)"
        powerSuperHero.text = "Power: \(param.powerstats?.power ?? 0)"
        DispatchQueue.global().async {
            guard let imageSuperHeros = param.images?.sm else { return }
            guard let imageUrl = URL(string: imageSuperHeros) else { return }
            guard let imageData = try? Data(contentsOf: imageUrl) else { return }
            DispatchQueue.main.async {
                self.imageSuperHero.image = UIImage(data: imageData)
            }
        }
    }
}
    
  


