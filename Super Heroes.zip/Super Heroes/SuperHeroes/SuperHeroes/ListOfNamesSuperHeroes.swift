//
//  ListOfNamesSuperHeroes.swift
//  SuperHeroes
//
//  Created by asus on 3/23/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import UIKit
import Alamofire




class ListOfNamesSuperHeroes: UITableViewController {

    private let jsonUrl = "https://cdn.rawgit.com/akabab/superhero-api/0.2.0/api/all.json"
    private var superHeroes: [SuperHeroInformation] = []
    override func viewDidLoad() {
        super.viewDidLoad()

       fetchData()
       postReqest()
     
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return superHeroes.count
        
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! CellWithInformOfSuperHeroesTableViewCell
   
        let superHero = superHeroes[indexPath.row]
        cell.configureOfCell(with: superHero)
    
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    func fetchData()  {
        
        guard let url = URL(string: jsonUrl) else { return }
        URLSession.shared.dataTask(with: url) { (data, _, _) in
        guard  let data = data else { return }
        do {
                self.superHeroes = try JSONDecoder().decode([SuperHeroInformation].self, from: data)
                print(self.superHeroes)
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
                } catch let error {
                    print(error)
                  
            }
            
        } .resume()
        
    }
    
}


extension ListOfNamesSuperHeroes {
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "DitailInform"  else { return }
        guard let distanation = segue.destination as? DitailInformationViewController else { return }
        
        guard  let indexPath = tableView.indexPathForSelectedRow else { return }
        
        let heroes = superHeroes[indexPath.row]
        
        distanation.appearence = "Appearence"
       
        distanation.gender = "Gender: \(heroes.appearance?.gender ?? "")"
        distanation.race = "Race: \(heroes.appearance?.race ?? "")"
        guard let hight = heroes.appearance?.height, let wight = heroes.appearance?.weight, let aliases = heroes.biography?.aliases else { return }
        distanation.height = "Hight: \(hight[0] )"
        distanation.weight = "Weight: \(wight[0])"
        distanation.eyeColor = "Eye color: \(heroes.appearance?.eyeColor ?? "")"
        distanation.hairColor = "Hair color: \(heroes.appearance?.hairColor ?? "")"
        DispatchQueue.global().async {
            guard let image = heroes.images?.md else { return }
            guard let imageUrl = URL(string: image) else { return }
            guard let imageData = try? Data(contentsOf: imageUrl) else { return }
            DispatchQueue.main.async {
                distanation.imageHero.image = UIImage(data: imageData)
            }
            
        }
        
        distanation.biography = "Biography"
        distanation.fullName = "Fullname: \(heroes.biography?.fullName ?? "")"
        distanation.alterEgos = "Alter Egos: \(heroes.biography?.alterEgos ?? "")"
        
        distanation.aliases  = "Aliases: \(aliases[0])"
        distanation.placeOfBirth = "Place Of birth: \(heroes.biography?.placeOfBirth ?? "")"
        distanation.firstAppearance = "First appearance:\(heroes.biography?.firstAppearance ?? "")"
        distanation.publisher = "Publisher: \(heroes.biography?.publisher ?? "")"
    
        
    }
}
extension ListOfNamesSuperHeroes {
   
    private func postReqest() {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else { return }
       
        let userData = [
            "name" : "Donatello",
            "skils" : "fight"
        ]
        var request = URLRequest.init(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: userData, options: []) else { return }
        request.httpBody = httpBody
        
        URLSession.shared.dataTask(with: request) { (data, response, _) in
            guard let response = response, let data = data else { return }
            print(response)
            do{
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                print(json)
                
            } catch let error {
                print(error)
            }
        } .resume()
    }
}

