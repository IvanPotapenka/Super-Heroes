//
//  DitailInformationViewController.swift
//  SuperHeroes
//
//  Created by asus on 3/23/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import UIKit

class DitailInformationViewController: UIViewController {

   
    @IBOutlet var imageHero: UIImageView!
    
    
    @IBOutlet var appearanceHero: UILabel!
    
    @IBOutlet var genderHero: UILabel!
    @IBOutlet var raceHero: UILabel!
    @IBOutlet var heightHero: UILabel!
    @IBOutlet var weightHero: UILabel!
    @IBOutlet var eyeColorHero: UILabel!
    @IBOutlet var hairColorHero: UILabel!
    
    @IBOutlet var biographyHero: UILabel!
    
    @IBOutlet var fullNameHero: UILabel!
    @IBOutlet var alterEgosHero: UILabel!
    @IBOutlet var aliasesHero: UILabel!
    @IBOutlet var placeOfBirthHero: UILabel!
    @IBOutlet var firstAppearanceHero: UILabel!
    @IBOutlet var publisherHero: UILabel!
    
    
    var biography: String!
    
    var fullName: String!
    var alterEgos: String!
    var aliases: String!
    var placeOfBirth: String!
    var firstAppearance: String!
    var publisher: String!
    
    
    var appearence: String!
    
     var gender: String!
     var race: String!
     var height: String!
     var weight: String!
     var eyeColor: String!
     var hairColor: String!


    override func viewDidLoad() {
        super.viewDidLoad()
        setName()
       
    }
    
    func setName() {
        appearanceHero.text = appearence
        genderHero.text = gender
        raceHero.text = race
        heightHero.text = height
        weightHero.text = weight
        eyeColorHero.text = eyeColor
        hairColorHero.text = hairColor
        
        biographyHero.text = biography
        fullNameHero.text = fullName
        aliasesHero.text = aliases
        alterEgosHero.text = alterEgos
        placeOfBirthHero.text = placeOfBirth
        firstAppearanceHero.text = firstAppearance
        publisherHero.text = publisher
        
        
    }
   

}
