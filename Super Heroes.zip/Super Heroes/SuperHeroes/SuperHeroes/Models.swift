//
//  Models.swift
//  SuperHeroes
//
//  Created by asus on 3/23/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import Foundation


struct SuperHeroInformation: Decodable {
    let name: String?
    let powerstats: Powerstat?
    let appearance: Appearance?
    let biography: Biography?
    let work: Work?
    let connections: Connections?
    let images: Images?
}


struct Powerstat: Decodable {
    let intelligence: Int?
    let strength: Int?
    let power: Int?
    
}
struct Appearance: Decodable {
    let gender: String?
    let race: String?
    let height: [String]?
    let weight: [String]?
    let eyeColor: String?
    let hairColor: String?

}

struct Biography: Decodable {
    let fullName: String?
    let alterEgos: String?
    let aliases: [String]?
    let placeOfBirth: String?
    let publisher: String?
    let firstAppearance: String?
    
}

struct Work: Decodable {
    let occupation: String?

}

struct Connections: Decodable {
    let groupAffiliation: String?
    let relatives: String?
    
}

struct Images: Decodable {
    let sm: String?
    let md: String?
}
