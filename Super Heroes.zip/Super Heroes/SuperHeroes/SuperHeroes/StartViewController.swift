//
//  ViewController.swift
//  SuperHeroes
//
//  Created by asus on 3/23/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import UIKit

class StartViewController: UIViewController {

  
    @IBOutlet var superHeroes: UIButton!
    @IBOutlet var imageHero: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    superHeroes.tintColor = .blue
    superHeroes.layer.cornerRadius = 20
        
    }
}

